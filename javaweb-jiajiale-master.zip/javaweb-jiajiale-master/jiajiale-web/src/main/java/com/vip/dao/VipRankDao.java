package com.vip.dao;

import com.vip.entity.VipRankEntity;
import org.springframework.stereotype.Repository;

@Repository
public interface VipRankDao extends CRUDDao<VipRankEntity,Integer> {

	
}
