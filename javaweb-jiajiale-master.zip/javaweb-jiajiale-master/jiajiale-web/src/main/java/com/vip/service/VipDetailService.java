package com.vip.service;

import com.vip.ao.VipAo;

public interface VipDetailService {
    /**
     * 给我一个 ao 进行新增
     * @param ao
     * @throws Exception
     */
    void add (VipAo ao) throws  Exception;

}
