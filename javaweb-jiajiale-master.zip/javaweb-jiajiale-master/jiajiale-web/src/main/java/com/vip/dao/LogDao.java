package com.vip.dao;

import com.vip.entity.LogEntity;
import com.vip.entity.SysAccountEntity;

public interface LogDao extends CRUDDao<LogEntity,String> {
}
